<?php defined('BASEPATH') OR exit('No direct script access allowed');

Class Admin extends CI_Controller{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('M_Admin');
  }

  public function index()
  {
    if($this->session->userdata('level')==""){
      redirect('auth/login');
    }else{
      $this->template->load('admin/template','admin/home');
    }
  }

  public function profil()
  {
    if($this->session->userdata('level')==""){
      redirect('auth/login');
    }else{
      $id=$this->session->userdata('id');
      $data['dataProfil'] = $this->M_Admin->getDataAdmin($id);
      $this->template->load('admin/template','admin/profil', $data);
    }
  }

  public function pretest()
  {
    if($this->session->userdata('level')==""){
      redirect('auth/login');
    }else{
      $data['dataPretest']=$this->M_Admin->getPretest1();
      $this->template->load('admin/template','admin/pretest',$data);
    }
  }
  
  public function addPretestQuestion()
  {
    if($this->session->userdata('level')==""){
      redirect('auth/login');
    }else{
      $this->template->load('admin/template','admin/addPretestForm');
    }
  }
  
  public function addPretestQuestionSave()
  {
    if($this->session->userdata('level')==""){
      redirect('auth/login');
    }else{
      $pretestType = $this->input->post('pretestType');
      $question = $this->input->post('question');
      $answerA = $this->input->post('answerA');
      $answerB = $this->input->post('answerB');
      $answerC = $this->input->post('answerC');
      $answerD = $this->input->post('answerD');
      $rightAnswer = $this->input->post('rightAnswer');
      $data=array(
        'pretest_type' => $pretestType,
        'question' => $question,
        'answer' => $rightAnswer,
        'answer_A' => $answerA,
        'answer_B' => $answerB,
        'answer_C' => $answerC,
        'answer_D' => $answerD
      );
      $this->M_Admin->addPretestQuestionSave($data,'pretest');
      redirect('Admin/pretest');
    }
  }
  
  public function deletePretestQuestion($id_question)
  {
    if($this->session->userdata('level')==""){
      redirect('auth/login');
    }else{
      $this->M_Admin->deletePretestQuestion($id_question);
      redirect('Admin/pretest');
    }
  }

  public function editPretestQuestion($id_question)
  {
    if($this->session->userdata('level')==""){
      redirect('auth/login');
    }else{
      $data['dataQuestion'] = $this->M_Admin->getDataQuestion($id_question);
    $this->template->load('admin/template','admin/editPretestForm',$data);
    }
  }

  public function updatePretestQuestion()
  {
    if($this->session->userdata('level')==""){
      redirect('auth/login');
    }else{
      $id_question = $this->input->post('id_question');
      $question = $this->input->post('question');
      $answerA = $this->input->post('answerA');
      $answerB = $this->input->post('answerB');
      $answerC = $this->input->post('answerC');
      $answerD = $this->input->post('answerD');
      $rightAnswer = $this->input->post('rightAnswer');
      $data=array(
        'question' => $question,
        'answer' => $rightAnswer,
        'answer_A' => $answerA,
        'answer_B' => $answerB,
        'answer_C' => $answerC,
        'answer_D' => $answerD
      );
      $where=array('id_question' => $id_question);
      $this->M_Admin->updatePretestQuestion($where,$data,'pretest');
      redirect('Admin/pretest');
    }
  }

  public function editProfil($id)
  {
    if($this->session->userdata('level')==""){
      redirect('auth/login');
    }else{
      $data['dataAdmin']=$this->M_Admin->getDataAdmin($id);
      $this->template->load('admin/template','admin/editProfil',$data);
    }
  }

  public function updateProfil()
  {
    if($this->session->userdata('level')==""){
      redirect('auth/login');
    }else{
      $id = $this->input->post('id');
      $name = $this->input->post('name');
      //$username = $this->input->post('username');
      $email = $this->input->post('email');
      $password = $this->input->post('password');
      $data=array(
        'name' => $name,
        'email' => $email,
        'password' => $password
      );
      $where=array('id'=>$id);
      $this->M_Admin->updateProfil($where,$data,'user');
      redirect('admin/profil');
    }
  }

  public function getDataTest()
  {
    if($this->session->userdata('level')==""){
      redirect('auth/login');
    }else{
      $data['dataTest']=$this->M_Admin->getDataTest();
      $this->template->load('admin/template','admin/dataTest',$data);
    }
  }

  public function editEvaluation($id_user)
  {
    if($this->session->userdata('level')==""){
      redirect('auth/login');
    }else{
      $data['dataEvaluation']=$this->M_Admin->getDataTestEdit($id_user);
      $this->template->load('admin/template','admin/evaluation',$data);
    }
  }

  public function updateEvaluation()
  {
    if($this->session->userdata('level')==""){
      redirect('auth/login');
    }else{
      $id_user=$this->input->post('id_user');
      $trueAnswer=$this->input->post('trueAnswer');
      $wrongAnswer=$this->input->post('wrongAnswer');
      $score=$this->input->post('score');
      $data=array(
        'true_answer'=>$trueAnswer,
        'wrong_answer'=>$wrongAnswer,
        'score'=>$score
      );
      $data2=array('score_1'=>$score);
      $where=array('id_user'=>$id_user);
      $this->M_Admin->updateEvaluation($where,$data,'pretest_answer');
      $this->M_Admin->updateEvaluation2($where,$data2,'evaluation_member');
      redirect('admin/getDataTest');
    }
  }
  public function getDataScore()
  {
    if($this->session->userdata('level')==""){
      redirect('auth/login');
    }else{
      $data['dataScore']=$this->M_Admin->getDataScore();
    $this->template->load('admin/template','admin/score',$data);
    }
  }
}
