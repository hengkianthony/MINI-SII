<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller
{

  public function __construct()
  {
    parent::__construct();
    $this->load->model('M_Auth');
  }

  public function index()
  {
    if($this->session->userdata('level')==""){
      redirect('auth/login');
    }else{
      $this->template->load('admin/template','admin/home');
    }
  }

  public function login()
  {
    if($this->input->post()== NULL){
      $this->load->view('login');
    }else{
      $username = $this->input->post('username');
      $password = $this->input->post('password');
      $userCheck = $this->db->query("SELECT*FROM user WHERE username='$username' and password='$password'");
      if($userCheck->num_rows()==1){
        foreach($userCheck->result() as $row){
          $sess_data['id'] = $row->id;
          $sess_data['email'] = $row->email;
          $sess_data['username'] = $row->username;
          $sess_data['level'] = $row->level;
          $sess_data['name'] = $row->name;
          $this->session->set_userdata($sess_data);
        }
        if($row->level==1){
          redirect('Admin');
        }else{
          redirect('Member');
        }
      }else{
        ?>
        <script type="text/javascript">
        alert('Username or Password Incorrect');
        window.location="<?php echo base_url('index.php/auth/login');?>";
        </script>
        <?php
      }
    }
  }

  public function logout()
  {
    $this->session->unset_userdata('id');
    $this->session->unset_userdata('username');
    $this->session->unset_userdata('email');
    $this->session->unset_userdata('level');
    session_destroy();
    redirect('auth/login');
  }
  
  public function signUp()
  {
    $this->load->view('signUp');
  }

  public function signUpAction()
  {
    $name=$this->input->post('name');
    $username=$this->input->post('username');
    $email=$this->input->post('email');
    $password=$this->input->post('password');
    $noHandPhone=$this->input->post('noHandPhone');
    $level=2;
    $data=array(
      'name'=> $name,
      'username'=>$username,
      'email'=>$email,
      'password'=>$password,
      'noHandPhone'=>$noHandPhone,
      'level'=>$level
    );
    $this->M_Auth->signUpAction($data,'user');
    redirect('auth/login');

  }
}
