<?php defined('BASEPATH') OR exit('No direct script access allowed');

Class Member extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model('M_Member');
    }

    public function index()
    {
        if($this->session->userdata('level')==""){
            redirect('auth/login');
        }else{
            $this->template->load('member/template','member/home');
        }
    }

    public function profil()
    {
        if($this->session->userdata('level')==""){
            redirect('auth/login');
        }else{
            $id=$this->session->userdata('id');
            $data['dataProfil'] = $this->M_Member->getDataMember($id);
            $this->template->load('member/template','member/profil', $data);
        }
    }

    public function editProfil($id)
    {
        if($this->session->userdata('level')==""){
            redirect('auth/login');
        }else{
            $data['dataMember']=$this->M_Member->getDataMember($id);
            $this->template->load('member/template','member/editProfil',$data);
        }
    }

    public function updateProfil()
    {
        if($this->session->userdata('level')==""){
            redirect('auth/login');
        }else{
            $id = $this->input->post('id');
            $name = $this->input->post('name');
            //$username = $this->input->post('username');
            $email = $this->input->post('email');
            $password = $this->input->post('password');
            $data=array(
            'name' => $name,
            'email' => $email,
            'password' => $password
            );
            $where=array('id'=>$id);
            $this->M_Member->updateProfil($where,$data,'user');
            redirect('member/profil');
        }
    }

    public function pretest()
    {
        if($this->session->userdata('level')==""){
            redirect('auth/login');
        }else{
            $id_user=$this->session->userdata('id');
            $answerCheck=$this->db->query("SELECT id_user FROM pretest_answer WHERE id_user=$id_user");
            if($answerCheck->num_rows()==0){
                $data['dataPretest']=$this->M_Member->getPretest1();
                $this->template->load('member/template','member/pretest',$data);    
            }else{
            ?>
                <script type="text/javascript">
                alert('Anda Menyelesaikan Pretest Matematika Dasar');
                window.location="<?php echo base_url('index.php/member');?>";
                </script>
            <?php
            } 
        } 
    }

    public function saveAnswerPretest()
    {
        if($this->session->userdata('level')==""){
            redirect('auth/login');
        }else{
            $date=date('y-m-d');
            $username=$this->session->userdata('username');
            $id_user=$this->session->userdata('id');
            $answer[0]=$this->input->post('answer[0]');
            $answer[1]=$this->input->post('answer[1]');
            $answer[2]=$this->input->post('answer[2]');
            $answer[3]=$this->input->post('answer[3]');
            $answer[4]=$this->input->post('answer[4]');
            $answer[5]=$this->input->post('answer[5]');
            $answer[6]=$this->input->post('answer[6]');
            $answer[7]=$this->input->post('answer[7]');
            $answer[8]=$this->input->post('answer[8]');
            $score_1=0;
            $score_2=0;
            $score_3=0;
            $data=array(
                'dateTest' =>$date,
                'username' => $username,
                'id_user' => $id_user,
                'no_1' => $answer[0],
                'no_2' => $answer[1],
                'no_3' => $answer[2],
                'no_4' => $answer[3],
                'no_5' => $answer[4],
                'no_6' => $answer[5],
                'no_7' => $answer[6],
                'no_8' => $answer[7],
                'no_9' => $answer[8],
            );
            $data2=array(
                'id_user'=>$id_user,
                'score_1'=>$score_1,
                'score_2'=>$score_2,
                'score_3'=>$score_3
            );
            $this->M_Member->saveAnswerPretest($data,'pretest_answer');
            $this->M_Member->addEvaluationRow($data2,'evaluation_member');
            redirect('member');
        }
    }
}