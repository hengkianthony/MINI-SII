<?php defined('BASEPATH') OR exit('No direct script access allowed');

Class M_Admin extends CI_Model
{
    function getPretest1()
    {
        $sql=$this->db->query("SELECT*FROM pretest WHERE pretest_type=1");
        return $sql->result();
    }

    function addPretestQuestionSave($data,$table)
    {
        return $this->db->insert($table,$data);
    }

    function deletePretestQuestion($id_question)
    {
        $sql=$this->db->query("DELETE FROM pretest WHERE id_question=$id_question");
    }

    function getDataQuestion($id_question)
    {
        $sql=$this->db->query("SELECT*FROM pretest WHERE id_question=$id_question");
        return $sql->result();
    }

    function updatePretestQuestion($where,$data,$table)
    {
        $this->db->where($where);
        $this->db->update($table,$data);
    }

    function getDataAdmin($id)
    {
        $sql=$this->db->query("SELECT*FROM user WHERE id=$id");
        return $sql->result();
    }
    
    function updateProfil($where,$data,$table)
    {
        $this->db->where($where);
        $this->db->update($table,$data);
    }

    function getDataTest()
    {
        $sql=$this->db->query("SELECT*,user.name AS name_member FROM pretest_answer JOIN user ON user.id=pretest_answer.id_user");
        return $sql->result();
    }

    function getDataTestEdit($id_user)
    {
        $sql=$this->db->query("SELECT*,user.name AS name_member FROM pretest_answer JOIN user ON user.id=pretest_answer.id_user WHERE id=$id_user");
        return $sql->result();
    }

    function updateEvaluation($where,$data,$table)
    {
        $this->db->where($where);
        $this->db->update($table,$data);
    }
    function updateEvaluation2($where,$data,$table)
    {
        $this->db->where($where);
        $this->db->update($table,$data);
    }

    function getDataScore()
    {
        $sql=$this->db->query("SELECT*,user.name AS name_member FROM evaluation_member JOIN user ON user.id=evaluation_member.id_user");
        return $sql->result();
    }
}?>