<?php defined('BASEPATH') OR exit('No direct script access allowed');

Class M_Auth extends CI_Model
{
    function signUpAction($data,$table)
    {
        return $this->db->insert($table,$data);
    }
}