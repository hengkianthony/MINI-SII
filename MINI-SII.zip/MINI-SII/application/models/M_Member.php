<?php defined('BASEPATH') OR exit('No direct script access allowed');

Class M_Member extends CI_Model
{
    function getDataMember($id)
    {
        $sql=$this->db->query("SELECT*FROM user WHERE id=$id");
        return $sql->result();
    }

    function updateProfil($where,$data,$table)
    {
        $this->db->where($where);
        $this->db->update($table,$data);
    }

    function getPretest1()
    {
        $sql=$this->db->query("SELECT*FROM pretest WHERE pretest_type=1");
        return $sql->result();
    }

    function saveAnswerPretest($data,$table)
    {
        return $this->db->insert($table,$data);
    }

    function addEvaluationRow($data,$table)
    {
        return $this->db->insert($table,$data);
    }
}