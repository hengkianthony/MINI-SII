<main role="main" class="container">
  <h3 class="mt-1">Tambah Soal Pretest : Matematika Dasar </h3>
  <div class="card">
    <div class="card-body">
        <form method="post" role="form" action="addPretestQuestionSave">
            <div class="form-group">
                <label>Jenis Pretest</label>
                <input class="form-control" disabled type="text" value="Matematika Dasar"></input>
                <input class="form-control" type="hidden" name="pretestType" id="pretestType" value="1"></input>
            </div>
            <div class="form-group">
                <label>Pertanyaan</label>
                <input class="form-control" type="text" name="question" id="question"></input>
            </div>
            <div class="form-group">
                <label>Jawaban A</label>
                <input class="form-control" type="text" name="answerA" id="answerA"></input>
            </div>
            <div class="form-group">
                <label>Jawaban B</label>
                <input class="form-control" type="text" name="answerB" id="answerB"></input>
            </div>
            <div class="form-group">
                <label>Jawaban C</label>
                <input class="form-control" type="text" name="answerC" id="answerC"></input>
            </div>
            <div class="form-group">
                <label>Jawaban D</label>
                <input class="form-control" type="text" name="answerD" id="answerD"></input>
            </div>
            <div class="form-group">
                <label>Jawaban Benar</label>
                <label class="radio-inline" style="margin-left:15px;"><input type="radio" name="rightAnswer" value="A"> A</label>
                <label class="radio-inline" style="margin-left:15px;"><input type="radio" name="rightAnswer" value="B"> B</label>
                <label class="radio-inline" style="margin-left:15px;"><input type="radio" name="rightAnswer" value="C"> C</label>
                <label class="radio-inline" style="margin-left:15px;"><input type="radio" name="rightAnswer" value="D"> D</label>
            </div>
           
            <button class="btn btn-md btn-primary" type="submit">Simpan</button>
            <a class="btn btn-md btn-warning" href="<?= base_url()?>index.php/admin/pretest" type="button">Batal</a>
        
        </form>
    </div>
  </div>
</main>
