<main role="main" class="container">
  <h2 class="mt-2">Data Test Peserta</h2>
  <table class="table table-striped">
    <thead style="align:center;">
        <th>No</th>
        <th>Tanggal Test</th>
        <th>Name</th>
        <th>Soal 1</th>
        <th>Soal 2</th>
        <th>Soal 3</th>
        <th>Soal 4</th>
        <th>Soal 5</th>
        <th>Soal 6</th>
        <th>Soal 7</th>
        <th>Soal 8</th>
        <th>Soal 9</th>
        <th>Jawaban Salah</th>
        <th>Jawaban Benar</th>
        <th>Nilai</th>
        <th></th>
    </thead>
      <?php 
      $no=1;
        foreach($dataTest as $dt)
        {
      ?>
    <tbody>
          <td><?=$no++?></td>
          <td><?=$dt->dateTest?></td>
          <td><?=$dt->name_member?></td>
          <td><?=$dt->no_1?></td>
          <td><?=$dt->no_2?></td>
          <td><?=$dt->no_3?></td>
          <td><?=$dt->no_4?></td>
          <td><?=$dt->no_5?></td>
          <td><?=$dt->no_6?></td>
          <td><?=$dt->no_7?></td>
          <td><?=$dt->no_8?></td>
          <td><?=$dt->no_9?></td>
          <td><?=$dt->wrong_answer ?></td>
          <td><?=$dt->true_answer?></td>
          <td><?=$dt->score?></td>
          <td>
            <a type="button" href="<?= base_url('index.php/admin/editEvaluation/'.$dt->id_user)?>" class="btn btn-sm btn-primary" style="color:white;">Nilai</a>
          </td>
    </tbody>
    <?php
        }
        ?>
  </table>
  
  </main>
