<main role="main" class="container">
  <h3 class="mt-1">Edit Soal Pretest : Matematika Dasar </h3>
  <div class="card">
    <div class="card-body">
    <?php
    foreach($dataQuestion as $dq)
    {
    ?>
        <form method="post" role="form" action="<?= base_url()?>index.php/admin/updatePretestQuestion">
            <div class="form-group">
                <label>Jenis Pretest</label>
                <input class="form-control" value="<?= $dq->id_question ?>" type="hidden" name="id_question" id="id_question"></>                
                <input class="form-control" value="<?= $dq->pretest_type ?>" disabled type="text" name="pretestType" id="pretestType"></>
            </div>
            <div class="form-group">
                <label>Pertanyaan</label>
                <input class="form-control" value="<?= $dq->question ?>" type="text" name="question" id="question"></input>
            </div>
            <div class="form-group">
                <label>Jawaban A</label>
                <input class="form-control" value="<?= $dq->answer_A ?>" type="text" name="answerA" id="answerA"></input>
            </div>
            <div class="form-group">
                <label>Jawaban B</label>
                <input class="form-control" value="<?= $dq->answer_B ?>" type="text" name="answerB" id="answerB"></input>
            </div>
            <div class="form-group">
                <label>Jawaban C</label>
                <input class="form-control" value="<?= $dq->answer_C ?>" type="text" name="answerC" id="answerC"></input>
            </div>
            <div class="form-group">
                <label>Jawaban D</label>
                <input class="form-control" value="<?= $dq->answer_D ?>" type="text" name="answerD" id="answerD"></input>
            </div>
            <div class="form-group">
                <label>Jawaban Benar</label>
                <input class="form-control" disabled value="<?= $dq->answer ?>" type="text" name="answerD" id="answerD"></input>
                <label class="radio-inline" style="margin-left:15px;"><input type="radio" name="rightAnswer" value="A"> A</label>
                <label class="radio-inline" style="margin-left:15px;"><input type="radio" name="rightAnswer" value="B"> B</label>
                <label class="radio-inline" style="margin-left:15px;"><input type="radio" name="rightAnswer" value="C"> C</label>
                <label class="radio-inline" style="margin-left:15px;"><input type="radio" name="rightAnswer" value="D"> D</label>
            </div>
           
            <button class="btn btn-md btn-primary" type="submit" onclick="return confirm('Apakah anda ingin merubah data ini?');">Perbaharui</button>
            <a class="btn btn-md btn-warning" href="<?= base_url()?>index.php/admin/pretest" type="button">Batal</a>
        
        </form>
        <?php
    }
    ?>
    </div>
  </div>
</main>
