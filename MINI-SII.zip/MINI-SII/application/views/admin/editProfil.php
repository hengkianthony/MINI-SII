<main role="main" class="container">
  <h2 class="mt-2">Ubah Profile</h2>
  <?php
    foreach($dataAdmin as $da)
    {
  ?>
    <form role="form" method="post" action="<?= base_url()?>index.php/admin/updateProfil">
        <div class="form-group">
            <label>Nama</label>
            <input class="form-control" name="name" id="name" value="<?= $da->name?>" type="text"></input>
        </div>
        <div class="form-group">
            <label>Nama Pengguna</label>
            <input class="form-control" disabled name="username" id="username" value="<?= $da->username?>" type="text"></input>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input class="form-control" name="email" id="email" value="<?= $da->email?>" type="text"></input>
        </div>
        <div class="form-group">
            <label>No.HP</label>
            <input class="form-control" name="noHandPhone" id="noHandPhone" value="<?= $da->noHandPhone?>" type="text"></input>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input class="form-control" name="password" id="password" value="<?= $da->password?>" type="password"></input>
        </div>
        <div class="form-group">
            <?php 
            $levelX ="";
            if($da->level==1){
                $levelX="Admin";
            }else{
                $levelX="Member";
            }
            ?>
            <label>Level</label>
            <input class="form-control" disabled value="<?= $levelX?>" type="text"></input>
        </div>
        <!--<div class="form-group">
            <select class="form-control" name="level" id="level">
                <option>Admin</option>
                <option>Member</option>
            </select>
        </div>-->
        <input name="id" id="id" type="hidden" value="<?= $da->id ?>"></input>
        <button type="submit" class="btn btn-md btn-primary" onclick="return confirm('Apakah anda ingin merubah data ini?');">Perbaharui Profile</button>
        <a class="btn btn-md btn-warning" href="<?= base_url()?>index.php/admin">Kembali</a>
    </form>
  <?php
    }
    ?>
</main>