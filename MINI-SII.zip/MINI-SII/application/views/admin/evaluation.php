<main role="main" class="container">
  <h3 class="mt-1">Penilaian </h3>
  <div class="card">
    <div class="card-body">
    <?php
        foreach($dataEvaluation as $de)
        {
    ?>
        <form method="post" role="form" action="<?=base_url()?>index.php/admin/updateEvaluation">
            <div class="form-group">
                <label>Nama Peserta</label>
                <input class="form-control" disabled type="text" value="<?= $de->name_member?>"></input>
                <input class="form-control" type="hidden" name="id_user" id="id_user" value="<?=$de->id_user?>"></input>
            </div>
            <div class="form-group">
                <label>Jawaban Benar</label>
                <input class="form-control" type="numeric" name="trueAnswer" id="trueAnswer" value="<?=$de->true_answer?>"></input>
            </div>
            <div class="form-group">
                <label>Jawaban Salah</label>
                <input class="form-control" value="<?=$de->wrong_answer?>" type="numeric" name="wrongAnswer" id="wrongAnswer"></input>
            </div>
            <div class="form-group">
                <label>Score</label>
                <input class="form-control" value="<?=$de->score?>" type="numeric" name="score" id="score"></input>
            </div>
            <button class="btn btn-md btn-primary" type="submit">Simpan</button>
            <a class="btn btn-md btn-warning" href="<?= base_url()?>index.php/admin/getDataTest" type="button">Batal</a>
        
        </form>
        <?php
        }
        ?>
    </div>
  </div>
</main>
