<main role="main" class="container">
  <h2 class="mt-2">Home Page</h2>
  <p class="lead">Selamat Datang Pada Halaman Beranda Admin</p>
  <div class="card">
    <div class="card-header">
      <b>Profil</b>
    </div>
    <div class="card-body">
      <p align="justify">Menu <b>Profil</b> menampilkan informasi identitas user, pada menu ini juga user dapat mengedit data user. seperti mengganti password akun, email dan nama.</p>
      <p align="left"><b>Cara mengupdate profile :</b></p>
      <p align="justify">
        1. Klik Menu <b>Profile</b></br>
        2. Klik Tombol <b>Ubah Profil</b></br>
        3. Isi pada form, data yang akan di rubah</br>
        4. Klik Tombol <b>Perbaharui</b> untuk menyimpan data yang telah di ubah</br>
      </p>
    </div>
  </div></br>
  <div class="card">
    <div class="card-header">
      <b>Pretest</b>
    </div>
    <div class="card-body">
      <p align="justify">
      Menu <b>Pretest</b> menapilkan daftar test, yang di setiap test nya terdapat beberapa pertanyaan/soal. Setiap soal didalam test terdiri 1 (satu) jawaban yang benar dari 4 (empat) pilihan jawaban yang tersedia.</br>
      Admin juga dapat menambah, merubah dan menghapus pertanyaan/soal di setiap test nya.
      </p>
      <p align="left"><b>Cara menambah pertanyaan/soal :</b></p>
      <p align="justify">
        1. Klik Menu <b>Pretest</b></br>
        2. Pilih jenis test yang ingin di perbaharui</br>
        3. Klik tombol <b>Tambah Pertanyaan</b></br>
        4. Isi data pertanyaan/soal pada form</br>
        5. Klik tombol <b>Simpan</b> untuk menyimpan data soal yang baru</br>
      </p></br>
      <p align="left"><b>Cara Merubah Data Pertanyaan/Soal :</b></p>
      <p align="justify">
        1. Klik Menu <b>Pretest</b></br>
        2. Pilih jenis test yang ingin di perbaharui</br>
        3. Klik tombol <b>Ubah</b> pada soal yang ingin di perbaharui</br>
        4. Isi data pertanyaan/soal yang ingin di perbaharui pada form</br>
        5. Klik tombol <b>Perbaharui</b> untuk menyimpan data soal yang baru</br>
      </p></br>
      <p align="left"><b>Cara Menghapus Data Pertanyaan/Soal :</b></p>
      <p align="justify">
        1. Klik Menu <b>Pretest</b></br>
        2. Pilih jenis test yang ingin di perbaharui</br>
        3. Klik tombol <b>Hapus</b> pada soal yang ingin di hapus</br>
      </p></br>
    </div>
  </div></br>
  <div class="card">
    <div class="card-header">
      <b>Data Test</b>
    </div>
    <div class="card-body">
      <p align="justify">Menu <b>Data Test</b> menampilkan data jawaban dari setiap peserta test yang sudah mengerjakan pretest.
      Pada menu ini admin bisa memeriksa jawaban dari peserta untuk setip test nya, dan pada menu ini juga admin biisa memberikan
      nilai serta jumlah jawaban yang benar dan salah.
      </p>
      <p align="left"><b>Cara memberikan nilai :</b></p>
      <p align="justify">
        1. Klik Menu <b>Data Test</b></br>
        2. Pilih pretest mana yang ingin di periksa</br>
        3. Klik Tombol <b>Nilai</b> untuk memberikan penilaian</br>
        3. Isi pada form sesuai data</br>
        4. Klik Tombol <b>Simpan</b> untuk menyimpan data yang telah diperiksa</br>
      </p>
    </div>
  </div></br>
  <div class="card">
    <div class="card-header">
      <b>Data Nilai</b>
    </div>
    <div class="card-body">
      <p align="justify">Menu <b>Data Nilai</b> menu ini menmapilkan perolehan nilai dari setiap peserta test untuk setiap test yang sudah di kerjakan.
      pada halaman ini admin bisa melihat perolehan nilai sehingga bisa memutuskan peserta test lulus atau tidak.
      </p>
    </div>
  </div></br>
</main>
