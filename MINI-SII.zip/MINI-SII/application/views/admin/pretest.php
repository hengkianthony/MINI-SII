<main role="main" class="container">
  <h2 class="mt-2">Pretest 1 : Matematika Dasar</h2>
  <div class="card">
    <div class="card-body">
        <form>
        <p class="lead">Daftar Soal Pretest : Matematika Dasar</p>
        <a class="btn btn-md btn-primary" style="color:white; margin-top:20px;margin-bottom:50px;" href="<?= base_url()?>index.php/admin/addPretestQuestion">Tambah Pertanyaan</a>
            <?php 
            $no = 1;
            foreach($dataPretest as $dp)
                {
                    ?>
                <div class="form-group">
                    <label style="font-weight:bold;"><?= $no++?>  .  <?= $dp->question ?></label>
                </div>
                <div class="form-group">
                    <label class="radio-inline">A. <?= $dp->answer_A?></label>
                    <label class="radio-inline" style="margin-left:15px;">B. <?= $dp->answer_B?></label>
                    <label class="radio-inline" style="margin-left:15px">C. <?= $dp->answer_C?></label>
                    <label class="radio-inline" style="margin-left:15px">D. <?= $dp->answer_D?></label>
                </div>
                <div class="form-group">
                    <a href="<?= base_url('index.php/admin/editPretestQuestion/'.$dp->id_question)?>" class="btn btn-md btn-warning" type="button">Ubah</a>
                    <a href="<?= base_url('index.php/admin/deletePretestQuestion/'.$dp->id_question)?>" class="btn btn-md btn-danger" onclick="return confirm('Apakah anda ingin menghapus data ini?');">Hapus</a>
                </div>
            <?php
            }
            ?>
        </form>
    </div>
  </div>
</main>