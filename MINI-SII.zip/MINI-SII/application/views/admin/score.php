<main role="main" class="container">
  <h2 class="mt-2">Data Nilai Peserta</h2>
  <table class="table table-striped">
    <thead style="align:center;">
        <th>No</th>
        <th>Name</th>
        <th>Nilai Pretest : Matematika Dasar</th>
        <th>Nilai Pretest : Psikotest</th>
        <th>Nilai Pretest : Test 3</th>
    </thead>
      <?php 
      $no=1;
        foreach($dataScore as $ds)
        {
      ?>
    <tbody>
          <td><?=$no++?></td>
          <td><?=$ds->name_member?></td>
          <td><?=$ds->score_1?></td>
          <td><?=$ds->score_2?></td>
          <td><?=$ds->score_3?></td>
    </tbody>
    <?php
        }
        ?>
  </table>
  
  </main>
