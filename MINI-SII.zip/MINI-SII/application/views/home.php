<main role="main" class="container">
  <h1 class="mt-5">Home Page</h1>
  <p class="lead">Selamat Datang Pada Halaman Home</p>
  <p>Back to <a href="../sticky-footer/">the default sticky footer</a> minus the navbar.</p>
</main>
