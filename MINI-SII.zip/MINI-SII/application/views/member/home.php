<main role="main" class="container">
  <h2 class="mt-2">Home Page</h2>
  <p class="lead">Selamat Datang Pada Halaman Beranda Peserta</p>
  <div class="card">
    <div class="card-header">
      <b>Profil</b>
    </div>
    <div class="card-body">
      <p align="justify">Menu <b>Profil</b> berisi informasi identitas user, pada menu ini juga user dapat mengedit data user. seperti mengganti password akun, email dan nama.</p>
      <p align="left"><b>Cara mengupdate profile :</b></p>
      <p align="justify">
        1. Klik Menu <b>Profile</b></br>
        2. Klik Tombol <b>Ubah Profil</b></br>
        3. Isi pada form, data yang akan di rubah</br>
        4. Klik Tombol <b>Perbaharui</b> untuk menyimpan data yang telah di ubah</br>
      </p>
    </div>
  </div></br>
  <div class="card">
    <div class="card-header">
      <b>Pretest</b>
    </div>
    <div class="card-body">
      <p align="justify">
      Menu <b>Pretest</b> berisi daftar test, yang di setiap test nya terdapat beberapa pertanyaan/soal. Setiap soal didalam test terdiri 1 (satu) jawaban yang benar dari 4 (empat) pilihan jawaban yang tersedia.</br>
      peserta test hanya di perkenankan mengerjakan soal hanya 1(satu) kali, setelah jawaban di simpan maka peserta test tidak bisa mengulangi untuk mengisi pretest tersebut.
      </p>
      <p align="left"><b>Cara mengisi soal :</b></p>
      <p align="justify">
        1. Klik Menu <b>Pretest</b></br>
        2. Pilih jenis test yang ingin di kerjakan</br>
        3. Isi huruf vocal dari jawaban yang menurut anda benar di input isian dibawah soal</br>
        4. Klik tombol <b>Simpan</b> untuk menyimpan data soal yang baru</br>
      </p></br>
    </div>
  </div>
</main>
