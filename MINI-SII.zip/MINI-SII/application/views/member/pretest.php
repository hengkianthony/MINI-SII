<main role="main" class="container">
  <h2 class="mt-2">Pretest 1 : Matematika Dasar</h2>
  <div class="card">
    <div class="card-body">
        <form role="form" method="post" action="saveAnswerPretest">
        <p class="lead">Pilih Salah Satu Jawaban Yang Menurut Anda Benar !</p>
            <?php 
            $no = 1;
            foreach($dataPretest as $dp)
                {
                    ?>
                <div class="form-group">
                    <label style="font-weight:bold;"><?= $no++?>  .  <?= $dp->question ?></label>
                </div>
                <div class="form-group">
                    <label class="radio-inline"> A. <?= $dp->answer_A?></label>
                    <label class="radio-inline" style="margin-left:15px;"> B. <?= $dp->answer_B?></label>
                    <label class="radio-inline" style="margin-left:15px"> C. <?= $dp->answer_C?></label>
                    <label class="radio-inline" style="margin-left:15px"> D. <?= $dp->answer_D?></label>
                    <input class="form-control" style="width:50px;" name="answer[]" id="answer[]"></input>
                </div>
            <?php
            }
            ?>
            <button type="submit" class="btn btn-md btn-primary" style="color:white; margin-top:20px;margin-bottom:50px;" onclick="return confirm('Apakah yakin ingin menyimpan jawaban anda? anda hanya bisa mengisi pretest ini 1 kali');">Simpan Jawaban</button>
            <a class="btn btn-md btn-secondary" style="margin-top:20px;margin-bottom:50px;" href="<?= base_url()?>index.php/member">Kembali</a>
        </form>
    </div>
  </div>
</main>