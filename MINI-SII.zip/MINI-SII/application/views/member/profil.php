<main role="main" class="container">
  <h2 class="mt-2">Member Profile</h2>
  <?php
    foreach($dataProfil as $dp)
    {
  ?>
  <form>
    <div class="form-group">
      <label>Nama</label>
      <input class="form-control" disabled type="text" value="<?= $dp->name?>"></input>
    </div>
    <div class="form-group">
      <label>Nama Pengguna</label>
      <input class="form-control" disabled type="text" value="<?= $dp->username?>"></input>
    </div>
    <div class="form-group">
      <label>Email</label>
      <input class="form-control" disabled type="text" value="<?= $dp->email?>"></input>
    </div>
    <div class="form-group">
      <label>No. HP</label>
      <input class="form-control" disabled type="numeric" value="(+62)<?= $dp->noHandPhone?>"></input>
    </div>
    <div class="form-group">
    <?php 
      $levelX ="";
      if($dp->level==1){
        $levelX="Admin";
      }else{
        $levelX="Member";
      }
    ?>
      <label>Level</label>
      <input class="form-control" disabled type="text" value="<?= $levelX?>"></input>
    </div>
    <a class="btn btn-md btn-primary" href="<?= base_url('index.php/member/editProfil/'.$dp->id)?>">Ubah Profil</a>
    <a class="btn btn-md btn-warning" href="<?= base_url('index.php/member')?>">Kembali</a>
  </form>
  <?php
    }
    ?>
</main>