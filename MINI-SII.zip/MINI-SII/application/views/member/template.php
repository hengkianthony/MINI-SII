<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?php echo base_url('assets/favicon2.ico') ?>">

    <title>MINI Project SII</title>

    <link href="<?php echo base_url('assets/bootstrap.min.css') ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/sticky-footer-navbar.css') ?>" rel="stylesheet">
    <script src="<?php echo base_url('assets/jquery-3.2.1.slim.min.js') ?>" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="<?php echo base_url('assets/popper.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/bootstrap.min.js') ?>"></script>
  </head>

  <body>
    <header>
      <nav class="navbar navbar-expand-md navbar-dark fixed-top bg-dark">
        <img class="image" src="<?php echo base_url('assets/favicon2.ico') ?>" style="width:40px;height:40px;margin-right:20px;">
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarCollapse">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url()?>index.php/member">Beranda</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url()?>index.php/member/profil">Profil</a>
            </li>
            <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                Pretest
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">
              <a class="dropdown-item" href="<?php echo base_url()?>index.php/member/pretest">Matematika Dasar</a>
              <a class="dropdown-item" href="#">Psikotest</a>
              </div>
            </li>
            <li class="nav-item">
            <a class="nav-link" href="<?php echo base_url()?>index.php/auth/logout">Keluar</a>
            </li>
          </ul>
        </div>
      </nav>
    </header>
    <?php echo($contents);?>
    <footer class="footer bg-dark">
      <div class="container">
        <center><span class="text-muted">Mini Project SII 2021</span></center>
      </div>
    </footer>
  </body>
</html>
