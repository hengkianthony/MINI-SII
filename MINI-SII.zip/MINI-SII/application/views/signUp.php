<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="<?php echo base_url('assets/favicon2.ico') ?>">

    <title>MINI PROJECT SSI</title>

    <link href="<?php echo base_url('assets/bootstrap.min.css') ?>" rel="stylesheet">
    <link href="<?php echo base_url('assets/sticky-footer-navbar.css') ?>" rel="stylesheet">
    <script src="<?php echo base_url('assets/jquery-3.2.1.slim.min.js') ?>" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="<?php echo base_url('assets/popper.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/bootstrap.min.js') ?>"></script>
  </head>

  <body>
    <section class="vh-100">
      <div class="container-fluid">
        <div class="row d-flex justify-content-center align-items-center h-100">
          <div class="col col-xl-10">
            <div class="card" style="border-radius: 1rem; background-color:#ebf5f5;">
              <div class="row g-0">
                <div class="col-md-6 col-lg-5 d-none d-md-block">
                  <img class="img-fluid" style="border-radius: 1rem 0 0 1rem; width:1000px; height:850px" src="<?php echo base_url('assets/img/ilustrasi.png');?>" alt="login form"/>
                </div>
                <div class="col-md-6 col-lg-7 d-flex align-items-center">
                  <div class="card-body p-4 p-lg-5 text-black">
                    <form class="form-signin" role="form" action="signUpAction" method="post">
                      <div class="d-flex align-items-center mb-3 pb-1">
                        <i class="fas fa-cubes fa-2x me-3" style="color: #ff6219;"></i>
                        <span class="h1 fw-bold mb-0">MINI SSI PROJECT</span>
                      </div>

                      <h5 class="fw-normal mb-3 pb-3" style="letter-spacing: 1px;">Mendaftar Akun</h5>

                      <div class="form-control mb-4" style="background-color:#ddeded">
                        <label>Nama</label>
                        <input required placeholder="Hengki Anthony" type="text" id="name" name="name" class="form-control"/></br>
                        
                        <label>Nama Pengguna</label>
                        <input placeholder="Anthony12" type="text" id="username" name="username" class="form-control"/></br>

                        <label>Email</label>
                        <input required placeholder="hengkianthony@gmail.com" type="text" id="email" name="email" class="form-control"/></br>

                        <label>Password</label>
                        <input required type="password" id="password" name="password" class="form-control" /></br>

                        <label>No. HP (+62)</label>
                        <input required type="numeric" placeholder="85320537944" id="noHandPhone" name="noHandPhone" class="form-control"/></br>
                      </div>

                      <div class="pt-1 mb-4">
                        <button class="btn btn-dark btn-lg btn-block" type="submit">Daftar</button>
                        <a class="btn btn-dark btn-lg btn-block" href="<?= base_url()?>index.php/auth">Masuk</a>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  </body>
</html>
