-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 29, 2021 at 04:12 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mini-sii`
--

-- --------------------------------------------------------

--
-- Table structure for table `evaluation_member`
--

CREATE TABLE `evaluation_member` (
  `id_user` int(11) NOT NULL,
  `score_1` int(11) NOT NULL,
  `score_2` int(11) NOT NULL,
  `score_3` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `evaluation_member`
--

INSERT INTO `evaluation_member` (`id_user`, `score_1`, `score_2`, `score_3`) VALUES
(2, 6, 0, 0),
(4, 5, 0, 0),
(6, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pretest`
--

CREATE TABLE `pretest` (
  `id_question` int(11) NOT NULL,
  `question` varchar(100) NOT NULL,
  `answer` varchar(5) NOT NULL,
  `pretest_type` int(11) NOT NULL,
  `answer_A` varchar(100) NOT NULL,
  `answer_B` varchar(100) NOT NULL,
  `answer_C` varchar(100) NOT NULL,
  `answer_D` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pretest`
--

INSERT INTO `pretest` (`id_question`, `question`, `answer`, `pretest_type`, `answer_A`, `answer_B`, `answer_C`, `answer_D`) VALUES
(1, '2 : 2 = ?', 'A', 1, '1', '4', '0.5', '3'),
(2, '14 : 4 = ?', 'B', 1, '4', '3.5', '5', '2'),
(3, '20 X 10 = ?', 'A', 1, '200', '250', '10', '30'),
(4, '1 X 20 : 2 =?', 'B', 1, '20', '10', '15', '22'),
(5, '15 : 3 X (2+5) = ?', 'A', 1, '50', '40', '30', '20'),
(6, '12  : 10 + 2 = ?', 'B', 1, '120', '3.2', '3', '14'),
(14, '20 : 2 =?', 'C', 1, '20', '5', '10', '18'),
(15, '20 X 1 : 2 =?', 'A', 1, '10', '5', '20', '18'),
(16, '20 X 1 : 2 + 2 - 1 =?', 'A', 1, '11', '14', '16', '8');

-- --------------------------------------------------------

--
-- Table structure for table `pretest_answer`
--

CREATE TABLE `pretest_answer` (
  `dateTest` date NOT NULL,
  `id_user` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `no_1` varchar(1) NOT NULL,
  `no_2` varchar(1) NOT NULL,
  `no_3` varchar(1) NOT NULL,
  `no_4` varchar(1) NOT NULL,
  `no_5` varchar(1) NOT NULL,
  `no_6` varchar(1) NOT NULL,
  `no_7` varchar(1) NOT NULL,
  `no_8` varchar(1) NOT NULL,
  `no_9` varchar(1) NOT NULL,
  `score` int(11) NOT NULL,
  `true_answer` int(11) NOT NULL,
  `wrong_answer` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pretest_answer`
--

INSERT INTO `pretest_answer` (`dateTest`, `id_user`, `username`, `no_1`, `no_2`, `no_3`, `no_4`, `no_5`, `no_6`, `no_7`, `no_8`, `no_9`, `score`, `true_answer`, `wrong_answer`) VALUES
('2021-08-29', 2, 'Anthony12', 'A', 'A', 'B', 'C', 'D', 'A', 'B', 'C', 'D', 6, 7, 2),
('2021-08-29', 4, 'Imron21', 'A', 'B', 'A', 'B', 'C', 'B', 'C', 'A', 'A', 5, 5, 4),
('2021-08-29', 6, 'aditya', 'A', 'B', 'C', '', 'D', 'A', 'B', 'C', 'A', 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `pretest_type`
--

CREATE TABLE `pretest_type` (
  `id_pretest` int(11) NOT NULL,
  `pretest_type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `pretest_type`
--

INSERT INTO `pretest_type` (`id_pretest`, `pretest_type`) VALUES
(1, 'Matematika'),
(2, 'Psikotest');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `level` int(11) NOT NULL,
  `noHandPhone` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `name`, `username`, `password`, `email`, `level`, `noHandPhone`) VALUES
(1, 'Admin', 'admin', 'admin123', 'admin23@gmail.com', 1, 85320537944),
(2, 'Hengki Anthony', 'Anthony12', 'anthony12', 'hengkianthony@gmail.com', 2, 85320537944),
(3, 'Muhammad Ramdani Lestaluhu', 'Ramdani@123', 'ramdani123', 'ramdaniCool@gmail.com', 2, 85320537944),
(4, 'Muhammad Imron', 'Imron21', 'imron123', 'imron@gmail.com', 2, 85320537988),
(6, 'Aditya Rohman Ghufroni', 'aditya', 'aditya12', 'aditya@gmail.com', 2, 85320537955);

-- --------------------------------------------------------

--
-- Table structure for table `user_master`
--

CREATE TABLE `user_master` (
  `id_user` int(11) NOT NULL,
  `user` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_master`
--

INSERT INTO `user_master` (`id_user`, `user`) VALUES
(1, 'Admin'),
(2, 'Member');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `evaluation_member`
--
ALTER TABLE `evaluation_member`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `pretest`
--
ALTER TABLE `pretest`
  ADD PRIMARY KEY (`id_question`);

--
-- Indexes for table `pretest_answer`
--
ALTER TABLE `pretest_answer`
  ADD PRIMARY KEY (`id_user`);

--
-- Indexes for table `pretest_type`
--
ALTER TABLE `pretest_type`
  ADD PRIMARY KEY (`id_pretest`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_master`
--
ALTER TABLE `user_master`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pretest`
--
ALTER TABLE `pretest`
  MODIFY `id_question` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
